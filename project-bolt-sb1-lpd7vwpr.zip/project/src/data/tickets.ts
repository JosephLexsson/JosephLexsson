import { Ticket } from '../types';

export const tickets: Ticket[] = [
  {
    id: '1',
    eventName: 'Summer Music Festival',
    date: '2024-07-15',
    time: '14:00',
    price: 89.99,
    location: 'Central Park Arena',
    category: 'Music',
    imageUrl: 'https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3',
    availableSeats: 250
  },
  {
    id: '2',
    eventName: 'Comedy Night Special',
    date: '2024-06-20',
    time: '20:00',
    price: 49.99,
    location: 'Laugh Factory',
    category: 'Comedy',
    imageUrl: 'https://images.unsplash.com/photo-1517457373958-b7bdd4587205',
    availableSeats: 100
  },
  {
    id: '3',
    eventName: 'Basketball Championship',
    date: '2024-08-05',
    time: '19:30',
    price: 129.99,
    location: 'Sports Complex',
    category: 'Sports',
    imageUrl: 'https://images.unsplash.com/photo-1504450758481-7338eba7524a',
    availableSeats: 500
  }
];