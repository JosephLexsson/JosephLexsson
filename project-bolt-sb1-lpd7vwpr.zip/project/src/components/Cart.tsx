import React from 'react';
import { ShoppingCart, X } from 'lucide-react';
import { CartItem } from '../types';

interface CartProps {
  items: CartItem[];
  onUpdateQuantity: (ticketId: string, newQuantity: number) => void;
  onRemoveItem: (ticketId: string) => void;
}

export function Cart({ items, onUpdateQuantity, onRemoveItem }: CartProps) {
  const total = items.reduce((sum, item) => sum + item.ticket.price * item.quantity, 0);

  if (items.length === 0) {
    return (
      <div className="bg-white rounded-lg p-6 shadow-lg">
        <div className="flex items-center justify-center space-x-2 text-gray-500">
          <ShoppingCart className="w-5 h-5" />
          <span>Your cart is empty</span>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg p-6 shadow-lg">
      <h2 className="text-xl font-bold mb-4">Shopping Cart</h2>
      <div className="space-y-4">
        {items.map((item) => (
          <div key={item.ticket.id} className="flex items-center justify-between pb-4 border-b">
            <div className="flex-1">
              <h3 className="font-medium">{item.ticket.eventName}</h3>
              <p className="text-sm text-gray-500">
                {new Date(item.ticket.date).toLocaleDateString()} at {item.ticket.time}
              </p>
            </div>
            <div className="flex items-center space-x-4">
              <select
                value={item.quantity}
                onChange={(e) => onUpdateQuantity(item.ticket.id, Number(e.target.value))}
                className="rounded border p-1"
              >
                {[1, 2, 3, 4, 5].map((num) => (
                  <option key={num} value={num}>
                    {num}
                  </option>
                ))}
              </select>
              <span className="w-20 text-right">${(item.ticket.price * item.quantity).toFixed(2)}</span>
              <button
                onClick={() => onRemoveItem(item.ticket.id)}
                className="text-gray-400 hover:text-red-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-6 flex justify-between items-center">
        <span className="text-lg font-bold">Total:</span>
        <span className="text-lg font-bold">${total.toFixed(2)}</span>
      </div>
      <button className="w-full mt-4 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors">
        Proceed to Checkout
      </button>
    </div>
  );
}