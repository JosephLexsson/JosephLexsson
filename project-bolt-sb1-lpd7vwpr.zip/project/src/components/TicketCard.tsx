import React from 'react';
import { Calendar, MapPin, Clock, Users } from 'lucide-react';
import { Ticket } from '../types';

interface TicketCardProps {
  ticket: Ticket;
  onAddToCart: (ticket: Ticket) => void;
}

export function TicketCard({ ticket, onAddToCart }: TicketCardProps) {
  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden transition-transform hover:scale-[1.02]">
      <img 
        src={ticket.imageUrl} 
        alt={ticket.eventName}
        className="w-full h-48 object-cover"
      />
      <div className="p-6">
        <div className="flex justify-between items-start mb-4">
          <h3 className="text-xl font-bold text-gray-900">{ticket.eventName}</h3>
          <span className="text-lg font-bold text-indigo-600">${ticket.price}</span>
        </div>
        
        <div className="space-y-2 mb-6">
          <div className="flex items-center text-gray-600">
            <Calendar className="w-4 h-4 mr-2" />
            <span>{new Date(ticket.date).toLocaleDateString()}</span>
          </div>
          <div className="flex items-center text-gray-600">
            <Clock className="w-4 h-4 mr-2" />
            <span>{ticket.time}</span>
          </div>
          <div className="flex items-center text-gray-600">
            <MapPin className="w-4 h-4 mr-2" />
            <span>{ticket.location}</span>
          </div>
          <div className="flex items-center text-gray-600">
            <Users className="w-4 h-4 mr-2" />
            <span>{ticket.availableSeats} seats available</span>
          </div>
        </div>
        
        <button
          onClick={() => onAddToCart(ticket)}
          className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition-colors"
        >
          Add to Cart
        </button>
      </div>
    </div>
  );
}