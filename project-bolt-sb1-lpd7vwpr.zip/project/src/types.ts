export interface Ticket {
  id: string;
  eventName: string;
  date: string;
  time: string;
  price: number;
  location: string;
  category: string;
  imageUrl: string;
  availableSeats: number;
}

export interface CartItem {
  ticket: Ticket;
  quantity: number;
}