import React, { useState } from 'react';
import { Ticket, CartItem } from './types';
import { tickets } from './data/tickets';
import { TicketCard } from './components/TicketCard';
import { Cart } from './components/Cart';
import { Ticket as TicketIcon } from 'lucide-react';

function App() {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  const addToCart = (ticket: Ticket) => {
    setCartItems((prevItems) => {
      const existingItem = prevItems.find((item) => item.ticket.id === ticket.id);
      if (existingItem) {
        return prevItems.map((item) =>
          item.ticket.id === ticket.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prevItems, { ticket, quantity: 1 }];
    });
  };

  const updateQuantity = (ticketId: string, newQuantity: number) => {
    setCartItems((prevItems) =>
      prevItems.map((item) =>
        item.ticket.id === ticketId ? { ...item, quantity: newQuantity } : item
      )
    );
  };

  const removeItem = (ticketId: string) => {
    setCartItems((prevItems) => prevItems.filter((item) => item.ticket.id !== ticketId));
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-indigo-600 text-white py-6">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <TicketIcon className="w-8 h-8" />
              <h1 className="text-2xl font-bold">TicketMaster</h1>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <h2 className="text-2xl font-bold mb-6">Available Events</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {tickets.map((ticket) => (
                <TicketCard
                  key={ticket.id}
                  ticket={ticket}
                  onAddToCart={addToCart}
                />
              ))}
            </div>
          </div>
          
          <div className="lg:col-span-1">
            <Cart
              items={cartItems}
              onUpdateQuantity={updateQuantity}
              onRemoveItem={removeItem}
            />
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;